import os
import sys
import json
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from functools import wraps

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, project_root)

# 使用完整数据对接版本，充分利用三个电子表格数据
print("🚀 使用完整数据对接分析引擎")
from spark.fault_analysis_complete import FaultAnalysisComplete as FaultAnalysis
import config.config as config
from auth.user_manager import user_manager

app = Flask(__name__, template_folder=os.path.join(project_root, 'web', 'templates'))
app.secret_key = 'your-secret-key-here-change-in-production'

# 认证装饰器
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def employee_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user' not in session:
            return redirect(url_for('login'))
        if session['user'].get('role') != 'employee':
            return jsonify({'success': False, 'message': '需要员工权限'}), 403
        return f(*args, **kwargs)
    return decorated_function

class FaultAnalysisAPI:
    def __init__(self):
        self.analyzer = None
    
    def get_analyzer(self):
        if self.analyzer is None:
            self.analyzer = FaultAnalysis()
        return self.analyzer

api = FaultAnalysisAPI()

# 认证相关路由
@app.route('/')
def index():
    """首页 - 根据用户角色跳转"""
    if 'user' in session:
        user_role = session['user'].get('role')
        if user_role == 'employee':
            return redirect(url_for('employee_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    """登录页面"""
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username', '')
        password = data.get('password', '')
        
        result = user_manager.login(username, password)
        
        if result['success']:
            session['user'] = result['user_data']
            session['session_id'] = result['session_id']
            return jsonify(result)
        else:
            return jsonify(result)
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    """注册页面"""
    if request.method == 'POST':
        data = request.get_json()
        username = data.get('username', '')
        password = data.get('password', '')
        role = data.get('role', 'user')
        real_name = data.get('real_name', '')
        phone = data.get('phone', '')
        email = data.get('email', '')
        
        result = user_manager.register(username, password, role, real_name, phone, email)
        return jsonify(result)
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    """退出登录"""
    if 'session_id' in session:
        user_manager.logout(session['session_id'])
    session.clear()
    return redirect(url_for('login'))

# 员工页面
@app.route('/employee/dashboard')
@login_required
def employee_dashboard():
    """员工仪表板"""
    if session['user'].get('role') != 'employee':
        return redirect(url_for('user_dashboard'))
    return render_template('employee_dashboard.html')

@app.route('/employee/users')
@employee_required
def employee_users():
    """员工用户管理"""
    return render_template('employee_users.html')

@app.route('/employee/analysis')
@employee_required
def employee_analysis():
    """员工数据分析"""
    return render_template('employee_analysis.html')

# 用户页面
@app.route('/user/dashboard')
@login_required
def user_dashboard():
    """用户仪表板"""
    return render_template('user_dashboard.html')

@app.route('/user/analysis')
@login_required
def user_analysis():
    """用户故障分析"""
    return render_template('user_analysis.html')

@app.route('/user/cost-analysis')
@login_required
def user_cost_analysis():
    """用户成本分析"""
    return render_template('user_cost_analysis.html')

@app.route('/user/profile')
@login_required
def user_profile():
    """用户个人资料"""
    return render_template('user_profile.html')

@app.route('/user/maintenance')
@login_required
def user_maintenance():
    """用户维修记录"""
    return render_template('user_maintenance.html')

# 认证API路由
@app.route('/api/auth/userinfo')
@login_required
def get_user_info():
    """获取当前用户信息"""
    username = session['user']['username']
    user_info = user_manager.get_user_info(username)
    if user_info:
        # 隐藏密码
        user_info.pop('password', None)
        return jsonify({'success': True, 'data': user_info})
    return jsonify({'success': False, 'message': '用户不存在'})

@app.route('/api/auth/update_profile', methods=['POST'])
@login_required
def update_user_profile():
    """更新用户资料"""
    data = request.get_json()
    username = session['user']['username']
    
    result = user_manager.update_user_info(username, **data)
    return jsonify(result)

@app.route('/api/auth/change_password', methods=['POST'])
@login_required
def change_password():
    """修改密码"""
    data = request.get_json()
    username = session['user']['username']
    
    result = user_manager.change_password(
        username, 
        data.get('old_password'), 
        data.get('new_password')
    )
    return jsonify(result)

@app.route('/api/employee/users')
@employee_required
def get_all_users():
    """获取所有用户（员工权限）"""
    users = user_manager.get_all_users()
    return jsonify({'success': True, 'data': users})

@app.route('/api/employee/stats')
@employee_required
def get_employee_stats():
    """获取员工专用统计数据（使用真实数据）"""
    try:
        # 获取用户统计信息
        user_stats = user_manager.get_user_stats()
        
        # 获取故障分析数据
        analyzer = api.get_analyzer()
        
        # 使用真实数据计算故障统计
        total_faults = len(analyzer.fault_df) if analyzer.fault_df is not None else 0
        
        # 使用真实维修记录计算平均成本
        avg_cost = 0
        if analyzer.records_df is not None and len(analyzer.records_df) > 0:
            avg_cost = analyzer.records_df['维修费用(元)'].mean()
        
        # 基于真实故障数据计算故障分类
        categories_data = []
        if analyzer.fault_df is not None:
            # 根据故障代码前缀分类
            def get_fault_category(code):
                prefix = code[0] if code else ''
                category_map = {'P': '动力系统故障', 'C': '底盘系统故障', 'B': '车身系统故障'}
                return category_map.get(prefix, '其他故障')
            
            analyzer.fault_df['category_name'] = analyzer.fault_df['故障代码'].apply(get_fault_category)
            category_counts = analyzer.fault_df['category_name'].value_counts()
            
            categories_data = [
                {'category_name': category, 'fault_count': count}
                for category, count in category_counts.items()
            ]
        
        # 基于真实维修记录计算故障原因统计
        reasons_data = []
        if analyzer.records_df is not None and len(analyzer.records_df) > 0:
            # 按维修项目分组统计
            reason_stats = analyzer.records_df.groupby('维修项目').agg({
                '维修费用(元)': ['count', 'mean', 'min', 'max']
            }).reset_index()
            
            reason_stats.columns = ['reason_name', 'occurrence_count', 'avg_cost', 'min_cost', 'max_cost']
            reasons_data = reason_stats.to_dict('records')
        
        return jsonify({
            'success': True, 
            'data': {
                'user_stats': user_stats,
                'fault_stats': {
                    'total_faults': total_faults,
                    'avg_cost': avg_cost,
                    'categories': categories_data,
                    'reasons': reasons_data
                }
            }
        })
    except Exception as e:
        print(f"获取员工统计数据失败: {e}")
        # 返回真实数据作为备用，如果分析器有数据
        try:
            analyzer = api.get_analyzer()
            if analyzer.fault_df is not None:
                total_faults = len(analyzer.fault_df)
                avg_cost = analyzer.records_df['维修费用(元)'].mean() if analyzer.records_df is not None else 0
                
                return jsonify({
                    'success': True,
                    'data': {
                        'user_stats': user_manager.get_user_stats(),
                        'fault_stats': {
                            'total_faults': total_faults,
                            'avg_cost': avg_cost,
                            'categories': [],
                            'reasons': []
                        }
                    }
                })
        except:
            pass
        
        # 最后才使用模拟数据
        return jsonify({
            'success': True,
            'data': {
                'user_stats': {
                    'total_users': 25,
                    'employee_count': 2,
                    'user_count': 23,
                    'active_today': 8,
                    'user_trend': [
                        {'month': '1月', 'count': 5},
                        {'month': '2月', 'count': 8},
                        {'month': '3月', 'count': 12},
                        {'month': '4月', 'count': 15},
                        {'month': '5月', 'count': 18},
                        {'month': '6月', 'count': 22},
                        {'month': '7月', 'count': 25}
                    ]
                },
                'fault_stats': {
                    'total_faults': 156,
                    'avg_cost': 850,
                    'categories': [
                        {'category_name': '发动机故障', 'fault_count': 45},
                        {'category_name': '电气系统', 'fault_count': 38},
                        {'category_name': '制动系统', 'fault_count': 28},
                        {'category_name': '传动系统', 'fault_count': 25},
                        {'category_name': '其他', 'fault_count': 20}
                    ],
                    'reasons': [
                        {'reason_name': '正常磨损', 'avg_cost': 650},
                        {'reason_name': '操作不当', 'avg_cost': 1200},
                        {'reason_name': '质量问题', 'avg_cost': 0},
                        {'reason_name': '环境因素', 'avg_cost': 850}
                    ]
                }
            }
        })

# 数据分析API路由（添加权限控制）
@app.route('/api/fault/categories')
@login_required
def get_fault_categories():
    """获取故障分类统计"""
    try:
        analyzer = api.get_analyzer()
        categories = analyzer.fault_classification().to_dict('records')
        return jsonify({'success': True, 'data': categories})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/fault/reasons')
@login_required
def get_fault_reasons():
    """获取故障原因分析"""
    try:
        analyzer = api.get_analyzer()
        reasons = analyzer.fault_reason_analysis().to_dict('records')
        return jsonify({'success': True, 'data': reasons})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/cost/trend')
@login_required
def get_cost_trend():
    """获取维修成本趋势"""
    try:
        analyzer = api.get_analyzer()
        trend = analyzer.cost_trend_analysis().to_dict('records')
        return jsonify({'success': True, 'data': trend})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/car/models')
@login_required
def get_car_models_analysis():
    """获取车型分析数据"""
    try:
        analyzer = api.get_analyzer()
        models = analyzer.car_model_analysis().to_dict('records')
        return jsonify({'success': True, 'data': models})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/recommendation', methods=['POST'])
@login_required
def get_maintenance_recommendation():
    """获取维修方案推荐"""
    try:
        data = request.get_json()
        car_model = data.get('car_model', '')
        mileage = data.get('mileage', 0)
        fault_phenomenon = data.get('fault_phenomenon', '')
        
        analyzer = api.get_analyzer()
        recommendations = analyzer.maintenance_recommendation(
            car_model, mileage, fault_phenomenon
        ).to_dict('records')
        
        return jsonify({'success': True, 'data': recommendations})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/analysis/report')
@login_required
def get_analysis_report():
    """获取完整分析报告"""
    try:
        analyzer = api.get_analyzer()
        report = analyzer.generate_analysis_report()
        
        # 确保返回的数据结构正确
        if not isinstance(report, dict):
            report = {
                'fault_category': [],
                'fault_reason': [],
                'cost_trend': [],
                'car_model': []
            }
        
        # 统一计算平均维修成本
        avg_cost = 0
        if 'fault_reason' in report and report['fault_reason']:
            # 使用故障原因数据计算平均成本
            avg_cost = sum(item.get('avg_cost', 0) for item in report['fault_reason']) / len(report['fault_reason'])
        elif analyzer.records_df is not None and len(analyzer.records_df) > 0:
            # 备用方案：使用原始维修记录数据
            avg_cost = analyzer.records_df['维修费用(元)'].mean()
        
        # 添加统计信息
        report['stats'] = {
            'total_faults': len(analyzer.fault_df) if analyzer.fault_df is not None else 0,
            'total_maintenance': len(analyzer.maintenance_df) if analyzer.maintenance_df is not None else 0,
            'total_records': len(analyzer.records_df) if analyzer.records_df is not None else 0,
            'avg_cost': avg_cost
        }
        
        return jsonify({'success': True, 'data': report})
    except Exception as e:
        print(f"获取分析报告失败: {e}")
        return jsonify({'success': False, 'error': str(e)})

# 保留原有页面路由，但添加权限控制
@app.route('/dashboard')
@login_required
def dashboard():
    """通用仪表板页面"""
    return render_template('dashboard.html')

@app.route('/fault-analysis')
@login_required
def fault_analysis():
    """故障分析页面"""
    return render_template('fault_analysis.html')

@app.route('/maintenance-recommendation')
@login_required
def maintenance_recommendation():
    """维修推荐页面"""
    return render_template('maintenance_recommendation.html')

@app.route('/cost-analysis')
@login_required
def cost_analysis():
    """成本分析页面"""
    return render_template('cost_analysis.html')

@app.teardown_appcontext
def close_analyzer(exception=None):
    """应用关闭时清理资源"""
    if api.analyzer:
        api.analyzer.close()
        api.analyzer = None

if __name__ == '__main__':
    app.run(
        host=config.FLASK_HOST, 
        port=config.FLASK_PORT, 
        debug=config.FLASK_DEBUG
    )